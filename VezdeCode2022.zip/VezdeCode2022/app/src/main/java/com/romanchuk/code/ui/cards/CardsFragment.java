package com.romanchuk.code.ui.cards;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.snackbar.Snackbar;
import com.romanchuk.code.R;
import com.romanchuk.code.cards_swipe.CardStatus;
import com.yuyakaido.android.cardstackview.CardStackLayoutManager;
import com.yuyakaido.android.cardstackview.CardStackListener;
import com.yuyakaido.android.cardstackview.CardStackView;
import com.yuyakaido.android.cardstackview.Direction;
import com.yuyakaido.android.cardstackview.Duration;
import com.yuyakaido.android.cardstackview.StackFrom;
import com.yuyakaido.android.cardstackview.SwipeAnimationSetting;
import com.yuyakaido.android.cardstackview.SwipeableMethod;

public class CardsFragment extends Fragment implements CardStackListener {

    private CardStackView cardStack;
    private CardsAdapter cardsAdapter;
    private Button btnAccept, btnDecline;
    private TextView tvChoosedCard;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_cards, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        cardStack = view.findViewById(R.id.card_stack_view);
        cardsAdapter = new CardsAdapter(requireContext());
        btnAccept = view.findViewById(R.id.accept);
        btnDecline = view.findViewById(R.id.decline);
        tvChoosedCard = view.findViewById(R.id.tvChoosedCard);

        final CardsViewModelFactory newsFactory = new CardsViewModelFactory(requireContext());
        final CardsViewModel cardsViewModel = new ViewModelProvider(getViewModelStore(), newsFactory)
                .get(CardsViewModel.class);

        CardStackLayoutManager manager = new CardStackLayoutManager(requireContext(), this);
        manager.setStackFrom(StackFrom.None);
        manager.setVisibleCount(3);
        manager.setTranslationInterval(8.0f);
        manager.setScaleInterval(0.95f);
        manager.setSwipeThreshold(0.3f);
        manager.setMaxDegree(20.0f);
        manager.setDirections(Direction.HORIZONTAL);
        manager.setCanScrollHorizontal(true);
        manager.setCanScrollVertical(true);
        manager.setSwipeableMethod(SwipeableMethod.AutomaticAndManual);
        cardStack.setLayoutManager(manager);
        cardStack.setAdapter(cardsAdapter);

        cardsViewModel.getCardsList().observe(getViewLifecycleOwner(), newsList -> {
            cardsAdapter.setItems(newsList);
            if (newsList.size() < 1) {
                Snackbar.make(cardStack, "Больше нет карт", Snackbar.LENGTH_SHORT).show();
            }
        });

        btnAccept.setOnClickListener(_v -> {
            SwipeAnimationSetting setting = new SwipeAnimationSetting.Builder()
                    .setDirection(Direction.Left)
                    .setDuration(Duration.Normal.duration)
                    .build();
            manager.setSwipeAnimationSetting(setting);
            cardStack.swipe();
            cardsViewModel.setChoosedCard();
            cardsViewModel.setStatus(CardStatus.ACTIVE, cardsAdapter.counter - 1);
            showDialog();
        });

        btnDecline.setOnClickListener(_v -> {
            SwipeAnimationSetting setting = new SwipeAnimationSetting.Builder()
                    .setDirection(Direction.Right)
                    .setDuration(Duration.Normal.duration)
                    .build();
            manager.setSwipeAnimationSetting(setting);
            cardStack.swipe();
            cardsViewModel.setStatus(CardStatus.INACTIVE, cardsAdapter.counter - 1);
        });

        cardsViewModel.getChoosedCard().observe(getViewLifecycleOwner(), choosedCard -> {
            cardStack.setVisibility(View.INVISIBLE);
            tvChoosedCard.setVisibility(View.VISIBLE);
            tvChoosedCard.setText(getString(R.string.active_order, choosedCard.getName()));
        });
    }


    @Override
    public void onCardDragging(Direction direction, float ratio) {
        if (direction == Direction.Left) {
            if (cardStack.findViewHolderForLayoutPosition(cardsAdapter.counter) != null)
                cardStack.findViewHolderForLayoutPosition(cardsAdapter.counter - 1).itemView.setBackgroundColor(Color.GREEN);
        } else if (direction == Direction.Right) {
            if (cardStack.findViewHolderForLayoutPosition(cardsAdapter.counter) != null)
                cardStack.findViewHolderForLayoutPosition(cardsAdapter.counter - 1).itemView.setBackgroundColor(Color.RED);
        }
    }

    @Override
    public void onCardSwiped(Direction direction) {

    }

    @Override
    public void onCardRewound() {

    }

    @Override
    public void onCardCanceled() {
        if (cardStack.findViewHolderForLayoutPosition(cardsAdapter.counter) != null)
            cardStack.findViewHolderForLayoutPosition(cardsAdapter.counter - 1).itemView.setBackgroundColor(Color.WHITE);
    }

    @Override
    public void onCardAppeared(View view, int position) {

    }

    @Override
    public void onCardDisappeared(View view, int position) {

    }

    public void showDialog() {
        new AlertDialog.Builder(requireContext())
                .setTitle("Заказ принят")
                .setMessage("")
                .setPositiveButton(android.R.string.yes, (dialog, which) -> dialog.cancel())
                .show();
    }
}
