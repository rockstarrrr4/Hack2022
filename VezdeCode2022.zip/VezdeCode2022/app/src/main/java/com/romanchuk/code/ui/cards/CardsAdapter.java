package com.romanchuk.code.ui.cards;

import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.romanchuk.code.R;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CardsAdapter extends RecyclerView.Adapter<CardsAdapter.PostViewHolder> {
    Context mContext;
    ArrayList<CardModel> cards;
    int counter = 0;

    public CardsAdapter(Context mContext) {
        this.mContext = mContext;
    }

    public void setItems(ArrayList<CardModel> r) {
        this.cards = r;
        notifyDataSetChanged();
    }

    public void removeTopItem() {
        cards.remove(0);
        notifyItemRemoved(0);
    }

    public int getCounter() {
        return counter;
    }

    @NonNull
    @Override
    public PostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.card_layout, parent, false);
        return new PostViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PostViewHolder holder, int position) {
        counter = holder.getAdapterPosition() - 1;
        CardModel card = cards.get(position);
        holder.name.setText(card.getName());
        holder.address.setText(card.getAddress());
        holder.time.setText(card.getTime());
    }

    @Override
    public int getItemCount() {
        if (cards != null) {
            return cards.size();
        }
        return 0;
    }

    static class PostViewHolder extends RecyclerView.ViewHolder {
        TextView name, address, time;

        public PostViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.tvName);
            address = itemView.findViewById(R.id.tvAddress);
            time = itemView.findViewById(R.id.tvTime);
        }
    }
}

