package com.romanchuk.code.ui.cards;

import android.content.Context;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.romanchuk.code.cards_swipe.CardStatus;

import java.util.ArrayList;
import java.util.Objects;

public class CardsViewModel extends ViewModel {
    private final MutableLiveData<ArrayList<CardModel>> cards;
    private MutableLiveData<CardModel> choosedCard;
    private MutableLiveData<Integer> choosedCardIndex;

    public CardsViewModel() {
        this.cards = new MutableLiveData<>();
        this.choosedCard = new MutableLiveData<>();
        this.choosedCardIndex = new MutableLiveData<>();
        choosedCardIndex.postValue(0);
        ArrayList<CardModel> cardModels = new ArrayList<>();
        cardModels.add(new CardModel("Заказ 1", "djhk1", "sdkgldg", CardStatus.INACTIVE));
        cardModels.add(new CardModel("Заказ 2", "djhk2", "sdkgldg", CardStatus.INACTIVE));
        cardModels.add(new CardModel("Заказ 3", "djhk3", "sdkgldg", CardStatus.INACTIVE));
        cardModels.add(new CardModel("Заказ 4", "djhk1", "sdkgldg", CardStatus.INACTIVE));
        cardModels.add(new CardModel("Заказ 5", "djhk2", "sdkgldg", CardStatus.INACTIVE));
        cardModels.add(new CardModel("Заказ 6", "djhk3", "sdkgldg", CardStatus.INACTIVE));
        cardModels.add(new CardModel("Заказ 7", "djhk2", "sdkgldg", CardStatus.INACTIVE));
        cardModels.add(new CardModel("Заказ 8", "djhk3", "sdkgldg", CardStatus.INACTIVE));
        cards.postValue(cardModels);
    }

    public void incIndex() {
        if (this.choosedCardIndex.getValue() != null)
            this.choosedCardIndex.postValue(this.choosedCardIndex.getValue() + 1);
    }

    public void setChoosedCard() {
        choosedCard.postValue(cards.getValue().get(choosedCardIndex.getValue()));
    }

    public void setStatus(CardStatus status, int position) {
        ArrayList<CardModel> cards1 = getCardsList().getValue();
        CardModel cur = cards1.get(position);
        cur.setStatus(status);
        cards1.set(position, cur);
        this.cards.postValue(cards1);
    }

    public LiveData<CardModel> getChoosedCard() {
        return choosedCard;
    }

    public void removeTopItem() {
        ArrayList<CardModel> cards1 = getCardsList().getValue();
        cards1.remove(0);
        this.cards.postValue(cards1);
    }

    public LiveData<ArrayList<CardModel>> getCardsList() {
        return cards;
    }
}
