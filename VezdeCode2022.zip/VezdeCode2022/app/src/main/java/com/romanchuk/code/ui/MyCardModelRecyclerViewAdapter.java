package com.romanchuk.code.ui;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.romanchuk.code.R;
import com.romanchuk.code.cards_swipe.CardStatus;
import com.romanchuk.code.databinding.FragmentHistoryBinding;
import com.romanchuk.code.ui.cards.CardModel;

import java.util.ArrayList;
import java.util.List;

public class MyCardModelRecyclerViewAdapter extends RecyclerView.Adapter<MyCardModelRecyclerViewAdapter.ViewHolder> {

    private ArrayList<CardModel> cards;
    Context mContext;

    public MyCardModelRecyclerViewAdapter(Context c) {
        mContext = c;
    }

    public void setItems(ArrayList<CardModel> r) {
        this.cards = r;
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.fragment_history, parent, false);
        return new MyCardModelRecyclerViewAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        CardModel card = cards.get(position);
        holder.name.setText(card.getName());
        holder.address.setText(card.getAddress());
        holder.time.setText(card.getTime());
        int color = 0;
        String info = "";
        if (card.getStatus().equals(CardStatus.ACTIVE)) {
            color = Color.YELLOW;
            info = "активный";
        }
        if (card.getStatus().equals(CardStatus.INACTIVE)) {
            color = Color.RED;
            info = "отклоненный";
        }
        if (card.getStatus().equals(CardStatus.CLOSED)) {
            color = Color.GREEN;
            info = "завершенный";
        }
        holder.status.setTextColor(color);
        holder.status.setText(info);
    }

    @Override
    public int getItemCount() {
        if (cards != null)
            return cards.size();
        return 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, address, time, status;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.tvName);
            address = itemView.findViewById(R.id.tvAddress);
            time = itemView.findViewById(R.id.tvTime);
            status = itemView.findViewById(R.id.tvStatus);
        }
    }
}