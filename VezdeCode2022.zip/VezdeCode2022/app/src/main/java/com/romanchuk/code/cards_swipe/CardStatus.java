package com.romanchuk.code.cards_swipe;

public enum CardStatus {
    ACTIVE,
    INACTIVE,
    CLOSED
}
