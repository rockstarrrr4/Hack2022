package com.romanchuk.code.ui.cards;

import com.romanchuk.code.cards_swipe.CardStatus;

public class CardModel {
    private String address;
    private String name;
    private String time;
    private CardStatus status;

    public CardModel(String name, String address, String time, CardStatus status) {
        this.address = address;
        this.name = name;
        this.time = time;
        this.status = status;
    }

    public String getAddress() {
        return address;
    }

    public String getName() {
        return name;
    }

    public String getTime() {
        return time;
    }

    public CardStatus getStatus() {
        return status;
    }

    public void setStatus(CardStatus status) {
        this.status = status;
    }
}
