package com.romanchuk.code.ui.cards;

public class CardModel {
    private String address;
    private String name;
    private String time;

    public CardModel(String address, String name, String time) {
        this.address = address;
        this.name = name;
        this.time = time;
    }

    public String getAddress() {
        return address;
    }

    public String getName() {
        return name;
    }

    public String getTime() {
        return time;
    }
}
