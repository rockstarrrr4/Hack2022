package com.romanchuk.code.cards_swipe;

import com.romanchuk.code.R;

public enum ModelObject {

    RED(R.string.order, R.layout.fragment_cards),
    BLUE(R.string.map, R.layout.fragment_cards);

    private int mTitleResId;
    private int mLayoutResId;

    ModelObject(int titleResId, int layoutResId) {
        mTitleResId = titleResId;
        mLayoutResId = layoutResId;
    }

    public int getTitleResId() {
        return mTitleResId;
    }

    public int getLayoutResId() {
        return mLayoutResId;
    }

}
